# ddc-ui-pum

pum.vim UI for ddc.vim

## Required

### denops.vim

https://github.com/vim-denops/denops.vim

### ddc.vim

https://github.com/Shougo/ddc.vim

### pum.vim

https://github.com/Shougo/pum.vim

## Configuration

```vim
call ddc#custom#patch_global('ui', 'pum')
```
