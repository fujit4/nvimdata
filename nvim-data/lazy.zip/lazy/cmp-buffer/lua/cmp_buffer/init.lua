return require('cmp_buffer.source').new()
