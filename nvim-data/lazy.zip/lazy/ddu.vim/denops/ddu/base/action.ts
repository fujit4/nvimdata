import type { ActionOptions } from "../types.ts";

export function defaultActionOptions(): ActionOptions {
  return {
    quit: true,
  };
}
