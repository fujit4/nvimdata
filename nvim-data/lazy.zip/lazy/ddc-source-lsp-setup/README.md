# ddc-source-lsp-setup

Setup for [ddc-source-lsp](https://github.com/Shougo/ddc-source-lsp).

The `capabilities` and `forceCompletionPattern` are automatically set to the appropriate ones.

```lua
require("ddc_source_lsp_setup").setup()

require("lspconfig").denols.setup()
```
