import { ensure } from "jsr:@core/unknownutil@^4.0.0/ensure";
import { isArray } from "jsr:@core/unknownutil@^4.0.0/is/array";
import { isNull } from "jsr:@core/unknownutil@^4.0.0/is/null";
import { isNumber } from "jsr:@core/unknownutil@^4.0.0/is/number";
import { isString } from "jsr:@core/unknownutil@^4.0.0/is/string";
import { isTupleOf } from "jsr:@core/unknownutil@^4.0.0/is/tuple-of";
import { isUnionOf } from "jsr:@core/unknownutil@^4.0.0/is/union-of";
import { Client, Session } from "jsr:@lambdalisue/messagepack-rpc@^2.4.0";
import { errorDeserializer, errorSerializer } from "../error.ts";
import { getVersionOr } from "../version.ts";
import { type Host, invoke, type Service } from "../host.ts";

export class Neovim implements Host {
  #session: Session;
  #client: Client;
  #service?: Service;

  constructor(
    reader: ReadableStream<Uint8Array>,
    writer: WritableStream<Uint8Array>,
  ) {
    this.#session = new Session(reader, writer, {
      errorSerializer,
    });
    this.#session.dispatcher = {
      void() {
        return Promise.resolve();
      },

      invoke: (method: unknown, args: unknown): Promise<unknown> => {
        if (!this.#service) {
          throw new Error("No service is registered in the host");
        }
        return invoke(
          this.#service,
          ensure(method, isString),
          ensure(args, isArray),
        );
      },

      nvim_error_event(type, message) {
        console.error(`nvim_error_event(${type})`, message);
      },
    };
    this.#session.onMessageError = (error, message) => {
      if (error instanceof Error && error.name === "Interrupted") {
        return;
      }
      console.error(`Failed to handle message ${message}`, error);
    };
    this.#session.start();
    this.#client = new Client(this.#session, {
      errorDeserializer,
    });
  }

  redraw(_force?: boolean): Promise<void> {
    // Do NOTHING on Neovim
    return Promise.resolve();
  }

  async call(fn: string, ...args: unknown[]): Promise<unknown> {
    try {
      return await this.#client.call("nvim_call_function", fn, args);
    } catch (err) {
      if (isNvimErrorObject(err)) {
        const [code, message] = err;
        throw new Error(
          `Failed to call '${fn}' in Neovim: ${message} (code: ${code})`,
        );
      }
      throw err;
    }
  }

  async batch(
    ...calls: (readonly [string, ...unknown[]])[]
  ): Promise<[unknown[], string]> {
    const result = await this.#client.call(
      "nvim_call_atomic",
      calls.map(([fn, ...args]) => ["nvim_call_function", [fn, args]]),
    );
    const [ret, err] = ensure(result, isNvimCallAtomicReturn);
    if (err) {
      const [index, code, message] = err;
      const fn = calls[index][0];
      return [
        ret,
        `Failed to call '${fn}' in Neovim: ${message} (code: ${code})`,
      ];
    }
    return [ret, ""];
  }

  async notify(fn: string, ...args: unknown[]): Promise<void> {
    await this.#client.notify("nvim_call_function", fn, args);
  }

  async init(service: Service): Promise<void> {
    const version = await getVersionOr({});
    await this.#client.call(
      "nvim_set_client_info",
      "denops",
      version,
      "msgpack-rpc",
      {
        invoke: {
          async: false,
          nargs: 2,
        },
      },
      {
        "website": "https://github.com/vim-denops/denops.vim",
        "license": "MIT",
        "logo":
          "https://github.com/vim-denops/denops-logos/blob/main/20210403-main/denops.png?raw=true",
      },
    );
    this.#service = service;
    this.#service.bind(this);
  }

  waitClosed(): Promise<void> {
    return this.#session.wait();
  }

  async [Symbol.asyncDispose](): Promise<void> {
    try {
      await this.#session.shutdown();
    } catch {
      // Do nothing
    }
  }
}

// nvim_call_function throws a special error object
// https://github.com/neovim/neovim/blob/5dc0bdfe98b59bb03226167ed541d17cc5af30b1/src/nvim/api/vimscript.c#L260
// https://github.com/neovim/neovim/blob/5dc0bdfe98b59bb03226167ed541d17cc5af30b1/src/nvim/api/private/defs.h#L63-L66
const isNvimErrorObject = isTupleOf([isNumber, isString] as const);

// nvim_call_atomics returns a tuple of [return values, error details]
const isNvimCallAtomicReturn = isTupleOf(
  [
    isArray,
    isUnionOf([
      isNull,
      // the index, the error type, the error message
      isTupleOf([isNumber, isNumber, isString] as const),
    ]),
  ] as const,
);
